<?php
    $name = (isset($_POST['userName'])) ? $_POST['userName'] : 'nome vazio';
    $computedString = "Olá, " . $name . "!";
    $array = ['userName' => $name, 'stringModificada' => $computedString];
    echo json_encode($array);
?>